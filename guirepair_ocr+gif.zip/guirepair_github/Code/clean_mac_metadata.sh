# chmod +x clean_mac_metadata.sh
# ./clean_mac_metadata.sh

#!/bin/bash
# clean_mac_metadata.sh
# 用途：清理 macOS 在外接硬盘或 Git 仓库中自动生成的无用缓存文件

echo "🧹 正在清理 macOS 元数据文件 (.DS_Store 和 ._*) ..."

# 删除 .DS_Store 文件
find . -name '.DS_Store' -type f -delete

# 删除以 ._ 开头的隐藏文件
find . -name '._*' -type f -delete

# 可选：清理 macOS 生成的 Icon\r 文件（Finder 目录图标）
find . -name 'Icon?' -delete

echo "✅ 清理完成。"
