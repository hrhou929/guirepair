import argparse
import os
from typing import Iterable, List, Optional

import imageio.v2 as imageio
import numpy as np

instance = r"E:\project\guirepair\Reproduce_Scenario_partial\test\bpmn-io"  # Set to a folder containing instances (e.g., "Reproduce_Scenario_partial/test/bpmn-io") to override prompts.
INSTANCE_OVERRIDE = instance.strip()

# Thresholding / spacing hyper-parameters
K = 1.2  # Scales the standard deviation when computing the global MAE threshold
MIN_GAP = 3  # Minimum number of frames that must pass before saving another key frame


def preprocess_frame(frame: np.ndarray, downscale: int = 2) -> np.ndarray:
    """
    Convert a frame into a normalized grayscale float array.

    Returning grayscale reduces sensitivity to minor color-only changes. Downscaling
    via simple slicing speeds up MAE computation without depending on heavy resizers.
    """
    arr = frame.astype(np.float32) / 255.0
    if arr.ndim == 3:
        arr = arr.mean(axis=2)  # crude grayscale projection
    if downscale > 1:
        arr = arr[::downscale, ::downscale]
    return arr


def mae(frame_a: np.ndarray, frame_b: np.ndarray) -> float:
    """
    Compute the Mean Absolute Error between two frames of the same shape.
    """
    return float(np.mean(np.abs(frame_a - frame_b)))


def ensure_output_dir(path: str) -> None:
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract semantic key frames from GUI GIF recordings across multiple instances."
    )
    parser.add_argument(
        "--root-dir",
        help="Folder containing instance subdirectories (e.g., Reproduce_Scenario_partial/test/bpmn-io). "
        "If omitted, you will be prompted.",
    )
    parser.add_argument(
        "--min-gap",
        type=int,
        default=MIN_GAP,
        help="Minimum number of frames between key frames.",
    )
    parser.add_argument(
        "--threshold-k",
        type=float,
        default=K,
        help="Multiplier for the MAE standard deviation when computing the global threshold.",
    )
    return parser.parse_args()


def resolve_root_dir(arg_value: Optional[str]) -> str:
    if INSTANCE_OVERRIDE:
        return INSTANCE_OVERRIDE
    if arg_value:
        return arg_value
    user_value = input("Enter the folder containing instances (e.g., path to bpmn-io): ").strip()
    if not user_value:
        raise ValueError("Root folder path is required.")
    return user_value


def iter_instance_dirs(root_dir: str) -> Iterable[str]:
    for entry in sorted(os.listdir(root_dir)):
        path = os.path.join(root_dir, entry)
        if os.path.isdir(path):
            yield path


def process_single_gif(
    instance_dir: str,
    gif_path: str,
    min_gap: int,
    threshold_k: float,
) -> None:
    # Save resulting PNG frames in the same folder where the GIF resides.
    output_dir = os.path.dirname(gif_path)

    print(f"  Loading frames from {gif_path} ...")
    reader = imageio.get_reader(gif_path)
    raw_frames: List[np.ndarray] = []
    proc_frames: List[np.ndarray] = []
    for frame in reader:
        raw_frames.append(frame)
        proc_frames.append(preprocess_frame(frame))

    total_frames = len(proc_frames)
    if total_frames == 0:
        print("No frames found in the GIF.")
        return

    # Always keep the very first frame to anchor the GUI state.
    key_frame_indices: List[int] = [0]

    if total_frames > 1:
        # Frame-to-frame MAE gives a distribution we can summarize with mean/std.
        mae_list = [mae(proc_frames[t], proc_frames[t - 1]) for t in range(1, total_frames)]
        mu = float(np.mean(mae_list))
        sigma = float(np.std(mae_list))
        tau = mu + threshold_k * sigma  # Global threshold; higher than average, so only significant changes pass.
        last_key_idx = 0

        print(f"Computed MAE stats: mu={mu:.6f}, sigma={sigma:.6f}, tau={tau:.6f}")

        for t in range(1, total_frames):
            # Prevent overly dense keyframes by enforcing a minimum gap.
            if t - last_key_idx < min_gap:
                continue

            # Compare to the last saved key frame, not merely the previous frame.
            # This suppresses small animation steps that would otherwise accumulate.
            current_mae = mae(proc_frames[t], proc_frames[last_key_idx])
            if current_mae > tau:
                key_frame_indices.append(t)
                last_key_idx = t
    else:
        print("Single-frame GIF; only the first frame will be saved.")
        tau = 0.0  # Defined for completeness.

    ensure_output_dir(output_dir)
    for idx in key_frame_indices:
        output_path = os.path.join(output_dir, f"frame_{idx:03d}.png")
        imageio.imwrite(output_path, raw_frames[idx])
        print(f"Saved key frame {idx} -> {output_path}")

    print("Selected key frame indices:", key_frame_indices)


def main() -> None:
    args = parse_args()
    root_dir = resolve_root_dir(args.root_dir)
    min_gap = max(1, args.min_gap)
    threshold_k = args.threshold_k

    if not os.path.isdir(root_dir):
        raise FileNotFoundError(f"Root directory does not exist: {root_dir}")

    print(f"Scanning instances under: {root_dir}")
    instance_dirs = list(iter_instance_dirs(root_dir))
    if not instance_dirs:
        print("No instance subdirectories found.")
        return

    for instance_dir in instance_dirs:
        image_dir = os.path.join(instance_dir, "IMAGE")
        if not os.path.isdir(image_dir):
            print(f"[SKIP] No IMAGE folder in {instance_dir}")
            continue
        gif_files = sorted(f for f in os.listdir(image_dir) if f.lower().endswith(".gif"))
        if not gif_files:
            print(f"[SKIP] No GIF recordings found in {instance_dir}")
            continue

        print(f"Processing instance: {instance_dir}")
        for gif_file in gif_files:
            gif_path = os.path.join(image_dir, gif_file)
            try:
                process_single_gif(
                    instance_dir=instance_dir,
                    gif_path=gif_path,
                    min_gap=min_gap,
                    threshold_k=threshold_k,
                )
            except Exception as exc:
                print(f"  [ERROR] Failed to process {gif_path}: {exc}")


if __name__ == "__main__":
    main()
