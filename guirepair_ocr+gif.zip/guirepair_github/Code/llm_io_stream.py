import subprocess
from openai import OpenAI
import anthropic
from pydantic import BaseModel
import json
import time
import re

import json5  # You might need to install this: pip install json5

def extract_json_from_text_refine(text: str, debug: bool = False):

    
    def pre_clean_text(raw: str) -> str:

        cleaned = re.sub(r'[^\x09\x0A\x0D\x20-\x7E\u4e00-\u9fa5\u3040-\u30FF\uFF00-\uFFEF\u0000-\uFFFF]', '', raw)
        

        cleaned = re.sub(r'\"{3,}', '"', cleaned)


        cleaned = re.sub(r'\\(C|M)-', r'\\\\\1-', cleaned)


        cleaned = re.sub(r'\\u\{([0-9a-fA-F]+)\}', lambda m: '\\u' + m.group(1).zfill(4)[-4:], cleaned)

        return cleaned

    def extract_main_json(cleaned_text: str) -> str:

        match = re.search(r'({[\s\S]*})', cleaned_text)
        if not match:
            raise ValueError("❌ ")
        return match.group(1)

    try:
        precleaned_text = pre_clean_text(text)

        if debug:
            print("🧼 ：")
            print(precleaned_text)

        json_str = extract_main_json(precleaned_text)

        if debug:
            print("🔍 ：")
            print(json_str)

        data = json5.loads(json_str)
        return data

    except Exception as e:
        return f"❌ JSON5 ERROR: {e}"

def extract_json_from_text(text: str, debug: bool = False):


    match = re.search(r'({[\s\S]*})', text)
    if not match:
        return "❌ "

    json_str = match.group(1)

    if debug:
        print("🔍 ")
        print(json_str)


    def clean_multiline_strings(s):

        lines = s.splitlines()
        result = []
        in_string = False
        for line in lines:
            line_strip = line.strip()
            if '"' in line_strip:
                quote_count = line_strip.count('"')
                if quote_count % 2 == 1:
                    in_string = not in_string
            if in_string:
                result.append(line_strip + '\\n')  
            else:
                result.append(line_strip)
        return ''.join(result)

    cleaned_json_str = clean_multiline_strings(json_str)

    if debug:
        print("✅ :")
        print(cleaned_json_str)

    # 尝试解析
    try:
        result_dict = json5.loads(cleaned_json_str)
        return result_dict
    except Exception as e:
        return f"❌ JSON5 ERROR: {e}"


def claude_chat(system_prompt, user_prompt, args, temperature, samples):

    client = anthropic.Anthropic(api_key=args.claude_api_key)

    # generate reproduce_code
    if "reproduce_code" in system_prompt and 'generate the reproduce code' in system_prompt:
        results = {}
        results_str = ''
        input_tokens, output_tokens = 0, 0
        key = 0
        while key < samples:
            completions = client.messages.create(
                max_tokens=8192,
                model=args.base_model,
                temperature=temperature,
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ]
            )
            # print(completions)
            key += 1
            for index, completion in enumerate(completions.content):
                result_str = completion.text
                result_dict = extract_json_from_text(completion.text)
                if 'JSON5 ERROR' in str(extract_json_from_text(completion.text)):
                    result_dict = extract_json_from_text_refine(completion.text)
                    print('1-------------------------------------')
                    if 'JSON5 ERROR' in str(extract_json_from_text_refine(completion.text)):
                        print('2-------------------------------------')
                        result_dict = {}
                        result_dict["reproduce_code"] = str(completion.text)
                   
                results_str += result_str
                results[key] = result_dict
            input_tokens += completions.usage.input_tokens
            output_tokens += completions.usage.output_tokens

    # locate file-level or find documents
    if "src/bug_file1.js" in system_prompt or "return all bug related documents" in system_prompt:
        results = {}
        results_str = ''
        input_tokens, output_tokens = 0, 0
        key = 0
        while key < samples:
            completions = client.messages.create(
                max_tokens=8192,
                model=args.base_model,
                temperature=temperature,
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ]
            )
            # print(completions)
            key += 1
            for index, completion in enumerate(completions.content):
                result_str = completion.text
                result_dict = extract_json_from_text(completion.text)
                if 'JSON5 ERROR' in str(extract_json_from_text(completion.text)):
                    result_dict = extract_json_from_text_refine(completion.text)
                results_str += result_str
                results[key] = result_dict
            input_tokens += completions.usage.input_tokens
            output_tokens += completions.usage.output_tokens


    # locate Class/Function-level
    if "class_name_1" in system_prompt and "function_name_1" in system_prompt:
        key = 0
        results = {}
        results_str = ''
        input_tokens, output_tokens = 0, 0
        while key < samples:
            completions = client.messages.create(
                max_tokens=8192,
                model=args.base_model,
                temperature=temperature,
                # n=samples,  # Request multiple completions
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ],
                # response_format={"type": "json"}
            )

            key += 1
            for index, completion in enumerate(completions.content):
                if 'JSON5 ERROR' not in str(extract_json_from_text(completion.text)):
                    result_str = completion.text
                    result_dict = extract_json_from_text(completion.text)
                    results_str += result_str
                    results[key] = result_dict
                else:
                    if 'JSON5 ERROR' in str(extract_json_from_text(completion.text)):
                        result_dict = extract_json_from_text_refine(completion.text)
                        results[key] = result_dict
                    result_str = completion.text
                    results_str += result_str
            input_tokens += completions.usage.input_tokens
            output_tokens += completions.usage.output_tokens


    # Generate Patches
    if "*SEARCH/REPLACE* edits" in system_prompt and "bug_code_snippets" in system_prompt:
        input_tokens, output_tokens = 0, 0
        results = {}
        results_str = ''

        completions = client.messages.create(
            max_tokens=8192,
            model=args.base_model,
            temperature=0.0,
            # n=1,  # Request one completions
            system=system_prompt,
            messages=[
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            # response_format=BugClassFunction
        )
        
        for key, completion in enumerate(completions.content):
            key += 1
            result_str = completion.text
            result_dict = completion.text
            results_str += result_str
            results[f'{1}/{samples}'] = result_dict
        input_tokens += completions.usage.input_tokens
        output_tokens += completions.usage.output_tokens
        
        if samples > 1:
            key = 1
            while key < samples:
                time.sleep(int(args.wait_time_after_api_request))  # wait -- seconds after api request

                current_temperature = temperature - (key-1) * 0.05
                current_temperature = max(current_temperature, 0.0)  

                completions = client.messages.create(
                    max_tokens=8000,
                    model=args.base_model,
                    temperature=current_temperature,
                    # n=samples-1,  # Request multiple completions
                    system=system_prompt,
                    messages=[
                        {
                            "role": "user",
                            "content": user_prompt
                        }
                    ]
                )
                key += 1
                for index, completion in enumerate(completions.content):
                    result_str = completion.text
                    result_dict = completion.text
                    results_str += result_str
                    results[f'{key}/{samples}'] = completion.text  # Ensure this is a string or serializable object
                input_tokens += completions.usage.input_tokens
                output_tokens += completions.usage.output_tokens

                
                

    # Extract token usage information
    token_usage = {}
    usage = completions.usage
    token_usage['base_model'] = args.base_model
    token_usage['prompt_tokens'] = input_tokens
    token_usage['completion_tokens'] = output_tokens
    token_usage['total_tokens'] = input_tokens + output_tokens

    time.sleep(int(args.wait_time_after_api_request))  # wait -- seconds after api request

    return results, results_str, token_usage  # Return a dict of results


def openai_chat(system_prompt, user_prompt, args, temperature, samples):

    class DocFiles(BaseModel):
        bug_scenario: str
        documents: list[str]
        explanation: str

    class ReproduceCode(BaseModel):
        bug_scenario: str
        reproduce_code: str
        explanation: str

    class BugFiles(BaseModel):
        bug_scenario: str
        bug_files: list[str]
        explanation: str

    class BugKeywords(BaseModel):
        bug_analyze: str
        bug_keywords: list[str]
        explanation: str

    class BugClassFunction(BaseModel):
        bug_scenario: str
        bug_classes: list[str]
        bug_functions: list[str]
        explanation: str

    class BugLine(BaseModel):
        bug_locations: str
        explanation: str

    class RefinedPatchFunction(BaseModel):
        Refined_Patch: str

    class RepairFeedback(BaseModel):
        bug_analyze: str
        patch_analyze: str
        final_answer: str

    # support custom OpenAI-compatible base URL (e.g. third-party proxy)
    client_kwargs = {}
    if getattr(args, "openai_api_key", ""):
        client_kwargs["api_key"] = args.openai_api_key
    if getattr(args, "openai_api_base", ""):
        # modern OpenAI client accepts base_url / api_base depending on SDK; here use base_url
        client_kwargs["base_url"] = args.openai_api_base
    client = OpenAI(**client_kwargs)

    if 'o4-mini' in args.base_model:
        temperature = 1

    # find documents
    if "src/path/document_1.js" in system_prompt and 'Document Structure' in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=DocFiles
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            # results.append((result.bug_scenario, result.bug_files, result.explanation))
            results[key] = {}
            results[key]['documents'] = result.documents
            results[key]['explanation'] = result.explanation
            results[key]['bug_scenario'] = result.bug_scenario

    # generate reproduce code
    if "reproduce_code" in system_prompt and 'Related Documents' in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=ReproduceCode
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            # results.append((result.bug_scenario, result.bug_files, result.explanation))
            results[key] = {}
            results[key]['reproduce_code'] = result.reproduce_code
            results[key]['explanation'] = result.explanation
            results[key]['bug_scenario'] = result.bug_scenario


    # locate file-level
    if "src/bug_file1.js" in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=BugFiles
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            # results.append((result.bug_scenario, result.bug_files, result.explanation))
            results[key] = {}
            results[key]['bug_files'] = result.bug_files
            results[key]['explanation'] = result.explanation
            results[key]['bug_scenario'] = result.bug_scenario

    # generate bug keywords
    if "bug_keywords" in system_prompt and "Explanation of why these keywords may appear in the bug files." in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=BugKeywords
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            # results.append((result.bug_scenario, result.bug_files, result.explanation))
            results[key] = {}
            results[key]['bug_analyze'] = result.bug_analyze
            results[key]['bug_keywords'] = result.bug_keywords
            results[key]['explanation'] = result.explanation


    # locate Class/Function-level
    if "class_name_1" in system_prompt and "function_name_1" in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=BugClassFunction
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            # results.append((result.bug_scenario, result.bug_files, result.explanation))
            results[key] = {}
            results[key]['bug_classes'] = result.bug_classes
            results[key]['bug_functions'] = result.bug_functions
            results[key]['explanation'] = result.explanation
            results[key]['bug_scenario'] = result.bug_scenario

    # locate line-level
    if "why these bug lines are" in system_prompt and "output the bug line number" in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples,  # Request multiple completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=BugLine
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            results[key] = {}
            try:
                results[key]['bug_locations'] = json.loads(result.bug_locations)
                results[key]['explanation'] = result.explanation
            except:
                results[key]['bug_locations'] = {}
                results[key]['explanation'] = ''

    # Generate Patches
    if "*SEARCH/REPLACE* edits" in system_prompt and "bug_code_snippets" in system_prompt:
        results = {}

        if 'o4-mini' in args.base_model: 
            temperature_patch=1
        else:
            temperature_patch=0.0
 
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature_patch,
            n=1,  # Request one completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            # response_format=BugClassFunction
        )
        for key, completion in enumerate(completions.choices):
            result = completion.message
            results[f'{1}/{samples}'] = result.content
        
        if samples > 1:
            completions = client.beta.chat.completions.parse(
                model=args.base_model,
                temperature=temperature,
                n=samples-1,  # Request multiple completions
                messages=[
                    {
                        "role": "system", 
                        "content": system_prompt
                    },
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ],
                # response_format=BugClassFunction
            )
            for key, completion in enumerate(completions.choices):
                
                key += 2
                result = completion.message
                results[f'{key}/{samples}'] = result.content  # Ensure this is a string or serializable object

    # check patch
    if "Refined Patch" in system_prompt:
        results = {}

        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=0.0,
            n=1,  # Request one completions
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            response_format=RefinedPatchFunction
        )

        
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed
            results[key] = {}
            results[key] = result.Refined_Patch
 
    # analyze repair feedback
    if "infering what the correct rendering" in system_prompt:
        completions = client.beta.chat.completions.parse(
            model=args.base_model,
            temperature=temperature,
            n=samples, 
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt['bug_analyze']
                },
                {
                    "role": "user",
                    "content": user_prompt['fix_analyze']
                }
            ],
            response_format=RepairFeedback
        )

        results = {}
        for key, completion in enumerate(completions.choices):
            key += 1
            result = completion.message.parsed

            results[key] = {}
            results[key]['bug_analyze'] = result.bug_analyze
            results[key]['patch_analyze'] = result.patch_analyze
            results[key]['final_answer'] = result.final_answer



    # Extract token usage information
    token_usage = {}
    usage = completions.usage
    token_usage['base_model'] = args.base_model
    token_usage['prompt_tokens'] = usage.prompt_tokens
    token_usage['completion_tokens'] = usage.completion_tokens
    token_usage['total_tokens'] = usage.total_tokens

    time.sleep(int(args.wait_time_after_api_request))  # wait -- seconds after api request

    return results, token_usage  # Return a dict of results