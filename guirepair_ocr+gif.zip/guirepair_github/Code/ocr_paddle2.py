#!/usr/bin/env python
"""Aggressive ROI-first OCR utility built on PaddleOCR."""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import shutil
import sys
import threading
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np
from paddleocr import PaddleOCR


_PADDLE_SUPPORTS_ORIENTATION_FLAG = True
_OCR_CALL_LOCK = threading.Lock()
_THREAD_LOCAL = threading.local()
_CODE_CLOSE_KERNEL = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 2))


def _patch_predict_kwargs(ocr_engine: PaddleOCR) -> None:
    """Wrap PaddleOCR.predict to ignore legacy cls/textline kwargs."""
    if getattr(ocr_engine, "_predict_wrapper_installed", False):
        return
    original_predict = ocr_engine.predict

    def wrapped_predict(*args, **kwargs):
        kwargs.pop("cls", None)
        kwargs.pop("angle_cls", None)
        kwargs.pop("textline_orientation", None)
        return original_predict(*args, **kwargs)

    ocr_engine.predict = wrapped_predict  # type: ignore[assignment]
    setattr(ocr_engine, "_predict_wrapper_installed", True)


def _to_rgb(img: np.ndarray) -> np.ndarray:
    """Convert OpenCV-loaded images (BGR/GRAY) to RGB for PaddleOCR.

    PaddleOCR generally expects RGB input; feeding BGR can severely hurt accuracy.
    """
    if img is None:
        return img
    if len(img.shape) == 2:
        return cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def _call_paddle_ocr(
    ocr_engine: PaddleOCR, rgb_img: np.ndarray, allow_cls: bool = True
):
    """Invoke PaddleOCR while gracefully handling deprecated cls argument."""
    global _PADDLE_SUPPORTS_ORIENTATION_FLAG
    kwargs = {}
    if allow_cls and _PADDLE_SUPPORTS_ORIENTATION_FLAG:
        kwargs["cls"] = True
    try:
        with _OCR_CALL_LOCK:
            return ocr_engine.ocr(rgb_img, **kwargs)
    except TypeError as exc:
        msg = str(exc).lower()
        if "unexpected keyword argument 'cls'" in msg:
            _PADDLE_SUPPORTS_ORIENTATION_FLAG = False
            _patch_predict_kwargs(ocr_engine)
            with _OCR_CALL_LOCK:
                return ocr_engine.ocr(rgb_img)
        raise


def _normalize_paddle_outputs(results: Sequence[object]) -> List[Dict[str, object]]:
    """Convert PaddleOCR outputs (new dict or legacy list formats) into a flat list."""
    normalized: List[Dict[str, object]] = []
    for entry in results or []:
        if isinstance(entry, dict):
            texts = entry.get("rec_texts") or []
            scores = entry.get("rec_scores") or []
            polys = entry.get("rec_polys") or entry.get("dt_polys") or []
            for idx, text in enumerate(texts):
                box = polys[idx] if idx < len(polys) else None
                score = scores[idx] if idx < len(scores) else 0.0
                normalized.append({"text": text, "score": float(score or 0.0), "box": box})
            continue
        if not entry:
            continue
        if isinstance(entry, (list, tuple)) and len(entry) >= 2:
            box = entry[0]
            payload = entry[1]
        else:
            continue
        if isinstance(payload, (list, tuple)) and payload:
            text = payload[0]
            score = float(payload[1]) if len(payload) > 1 else 0.0
        elif isinstance(payload, dict):
            text = payload.get("text", "")
            score = float(payload.get("score", 0.0))
        else:
            text = str(payload)
            score = 0.0
        normalized.append({"text": text, "score": score, "box": box})
    return normalized


def _box_to_xyxy(box: object) -> Optional[Tuple[int, int, int, int]]:
    if box is None:
        return None
    try:
        arr = np.asarray(box, dtype=float)
    except Exception:
        return None
    if arr.size == 0:
        return None
    if arr.ndim == 1:
        if arr.size % 2 != 0:
            return None
        arr = arr.reshape(-1, 2)
    if arr.shape[1] < 2:
        return None
    x_coords = arr[:, 0]
    y_coords = arr[:, 1]
    return (
        int(np.min(x_coords)),
        int(np.min(y_coords)),
        int(np.max(x_coords)),
        int(np.max(y_coords)),
    )


def _get_thread_cache() -> Dict[str, object]:
    cache = getattr(_THREAD_LOCAL, "ocr_cache", None)
    if cache is None:
        cache = {}
        setattr(_THREAD_LOCAL, "ocr_cache", cache)
    return cache


def _get_clahe(cache_key: str, clip_limit: float = 2.0, tile_size: Tuple[int, int] = (8, 8)):
    cache = _get_thread_cache()
    key = (cache_key, clip_limit, tile_size)
    clahe = cache.get(key)
    if clahe is None:
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_size)
        cache[key] = clahe
    return clahe


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
MIN_AREA_RATIO = 0.002
ERROR_KEYWORDS = [
    "error",
    "typeerror",
    "referenceerror",
    "stack",
    " at ",
    "failed",
    "exception",
    "traceback",
    "unhandled",
]
CODE_SYMBOLS = set("{}[]()<>:;=,._-/'\"\\|@#%*+!?~`^&$")
SYMBOL_LIGHT_MAP = str.maketrans(
    {
        "{": "(",
        "[": "(",
        "<": "(",
        "}": ")",
        "]": ")",
        ">": ")",
        "\uff08": "(",
        "\u3010": "(",
        "\u3011": ")",
        "\uff09": ")",
        "\uff1a": ":",
        "\uff1b": ":",
        "/": "/",
    }
)
PRESET_REPOSITORIES = [
    # 在此列表中添加常用仓库的绝对路径，脚本未传 image_root 时会自动使用第一项
    Path(r"E:\project\guirepair\Reproduce_Scenario_partial\test\carbon-design-system"),
]


@dataclass
class CandidateROI:
    box: Tuple[int, int, int, int]
    score: float


def str2bool(value: str) -> bool:
    if isinstance(value, bool):
        return value
    value = value.lower()
    if value in {"true", "1", "yes", "y", "on"}:
        return True
    if value in {"false", "0", "no", "n", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Cannot interpret boolean value from {value!r}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ROI first OCR utility")
    parser.add_argument(
        "--image_root",
        type=Path,
        action="append",
        default=[],
        help="Directory containing screenshots (can be provided multiple times)",
    )
    parser.add_argument(
        "--out_dir",
        type=Path,
        default=None,
        help="Custom output directory (defaults to OCR_OUT created inside each IMAGE folder)",
    )
    parser.add_argument(
        "--lang",
        choices=["en", "ch"],
        default="en",
        help="Language for PaddleOCR backbone",
    )
    parser.add_argument(
        "--upscale",
        type=int,
        default=3,
        choices=[1, 2, 3, 4],
        help="Bicubic upscale factor before OCR",
    )
    parser.add_argument(
        "--max_rois",
        type=int,
        default=30,
        help="Max ROI count per image (full image included in the cap)",
    )
    parser.add_argument(
        "--overwrite_outputs",
        type=str2bool,
        default=True,
        help="Whether to overwrite/clean existing OCR outputs under the output directory",
    )
    parser.add_argument(
        "--save_rois",
        type=str2bool,
        default=True,
        help="Whether to save ROI crops for debugging",
    )
    parser.add_argument(
        "--interactive_repo",
        action="store_true",
        help="Prompt to select a repository/folder when --image_root is not provided",
    )
    parser.add_argument(
        "--repo_base",
        type=Path,
        default=None,
        help="Optional base path that contains multiple repos (for interactive selection)",
    )
    parser.add_argument(
        "--max_workers",
        type=int,
        default=1,
        help="Worker threads for processing images. Use 0 to auto-select based on CPU count.",
    )
    return parser.parse_args()


def sanitize_worker_count(value: Optional[int]) -> int:
    if value is None:
        return 1
    if value <= 0:
        cpu_count = os.cpu_count() or 1
        return max(1, cpu_count - 1)
    return value


def setup_logger(log_file: Path) -> logging.Logger:
    logger = logging.getLogger("ocr_only_aggressive")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    return logger


def list_image_paths(root: Path) -> List[Path]:
    if not root.exists():
        raise FileNotFoundError(f"Image root {root} does not exist")
    paths: List[Path] = []
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in IMAGE_EXTS:
            if any(part.lower() == "ocr_out" for part in path.parts):
                continue
            paths.append(path)
    return sorted(paths)


def locate_image_directory(path: Path) -> Optional[Path]:
    """Return the IMAGE folder if present, otherwise the path itself."""
    candidate = path.expanduser().resolve()
    if not candidate.exists():
        return None
    image_dir = candidate / "IMAGE"
    return image_dir if image_dir.exists() else candidate


def is_within_repo(path: Path) -> bool:
    """Return True when the path sits under a directory named REPO."""
    return any(part.lower() == "repo" for part in path.parts)


def discover_image_directories(root: Path) -> List[Path]:
    """
    Locate IMAGE folders under the provided root, skipping anything under REPO.
    Falls back to the root itself when no IMAGE directory can be found.
    """
    if not root.exists():
        raise FileNotFoundError(f"Image root {root} does not exist")
    if root.name.lower() == "image":
        return [root]
    direct_image = root / "IMAGE"
    if direct_image.is_dir():
        return [direct_image]
    image_dirs: List[Path] = []
    try:
        children = sorted(child for child in root.iterdir() if child.is_dir())
    except PermissionError:
        children = []
    for child in children:
        candidate = child / "IMAGE"
        if candidate.is_dir() and not is_within_repo(candidate):
            image_dirs.append(candidate)
    if image_dirs:
        return image_dirs
    discovered: List[Path] = []
    seen: set[Path] = set()
    for candidate in root.rglob("IMAGE"):
        if not candidate.is_dir() or is_within_repo(candidate):
            continue
        resolved = candidate.resolve()
        if resolved not in seen:
            seen.add(resolved)
            discovered.append(resolved)
    if discovered:
        return sorted(discovered)
    return [root]


def render_progress(prefix: str, current: int, total: int, width: int = 40) -> None:
    """Lightweight console progress bar."""
    if total <= 0:
        return
    ratio = min(max(float(current) / float(total), 0.0), 1.0)
    filled = int(ratio * width)
    bar = "#" * filled + "-" * (width - filled)
    label = prefix[:20].ljust(20)
    sys.stdout.write(
        f"\r{label} |{bar}| {ratio * 100:6.2f}% ({current}/{total})"
    )
    sys.stdout.flush()
    if current >= total:
        sys.stdout.write("\n")


def prompt_repository_choices(base_dir: Optional[Path]) -> List[Path]:
    """
    Prompt user to select one or more repository folders manually.
    Returns a list of image directories (IMAGE folder when it exists).
    """
    raw_candidates: List[Path] = []
    preset_entries = [
        p for p in PRESET_REPOSITORIES if isinstance(p, Path) and str(p).strip()
    ]
    for entry in preset_entries:
        resolved = entry.expanduser().resolve()
        if resolved.exists() and resolved not in raw_candidates:
            raw_candidates.append(resolved)
    if base_dir and base_dir.exists():
        for child in sorted([p for p in base_dir.iterdir() if p.is_dir()]):
            resolved = child.resolve()
            if resolved not in raw_candidates:
                raw_candidates.append(resolved)
    if raw_candidates:
        print("检测到以下可选仓库目录（可输入多个序号，逗号分隔），或直接输入自定义路径：")
        for idx, repo in enumerate(raw_candidates, start=1):
            print(f"  [{idx}] {repo}")
        print("  [0] 手动输入新路径")
        print("  [all] 选择全部候选")
    selections: List[Path] = []
    while not selections:
        prompt = "请输入序号/路径（多个以逗号分隔）: " if raw_candidates else "请输入需要处理的仓库路径（可多个，逗号分隔）: "
        user_input = input(prompt).strip()
        if not user_input:
            print("输入为空，请重新输入。")
            continue
        tokens = [tok.strip() for tok in user_input.split(",") if tok.strip()]
        manual_entries: List[Path] = []
        for token in tokens:
            lowered = token.lower()
            if lowered in {"all", "*"} and raw_candidates:
                selections = raw_candidates.copy()
                break
            if lowered == "0" and raw_candidates:
                manual_path = input("请输入完整路径: ").strip().strip('"')
                if manual_path:
                    manual_entries.append(Path(manual_path))
                continue
            if token.isdigit() and raw_candidates:
                idx = int(token)
                if 1 <= idx <= len(raw_candidates):
                    selections.append(raw_candidates[idx - 1])
                else:
                    print(f"序号 {idx} 超出范围，将忽略。")
                continue
            manual_entries.append(Path(token.strip('"')))
        if manual_entries:
            selections.extend(manual_entries)
        if not selections:
            print("未解析到有效路径，请重新输入。")
    resolved_dirs: List[Path] = []
    for selection in selections:
        located = locate_image_directory(selection)
        if located:
            resolved_dirs.append(located)
        else:
            print(f"路径 {selection} 无效，已跳过。")
    unique_dirs: List[Path] = []
    for directory in resolved_dirs:
        if directory not in unique_dirs:
            unique_dirs.append(directory)
    return unique_dirs


def resolve_image_roots(args: argparse.Namespace) -> List[Path]:
    cli_roots: List[Path] = []
    for path in args.image_root:
        located = locate_image_directory(path)
        if not located:
            raise FileNotFoundError(f"指定的路径不存在：{path}")
        cli_roots.append(located)
    if cli_roots:
        return cli_roots
    if args.interactive_repo:
        selected = prompt_repository_choices(args.repo_base)
        if selected:
            print("已选择以下目录：")
            for item in selected:
                print(f"  - {item}")
            return selected
        raise ValueError("未选择任何有效目录。")
    auto_candidates: List[Path] = []
    for preset in PRESET_REPOSITORIES:
        located = locate_image_directory(preset)
        if located and located not in auto_candidates:
            auto_candidates.append(located)
    if auto_candidates:
        print("未提供 --image_root，自动使用预设目录：")
        for item in auto_candidates:
            print(f"  - {item}")
        return auto_candidates
    raise ValueError("必须提供至少一个 image_root，或使用 --interactive_repo 进行手动选择。")


def resolve_output_dir(image_root: Path, args: argparse.Namespace) -> Path:
    if args.out_dir:
        return args.out_dir.expanduser().resolve()
    return (image_root / "OCR_OUT").expanduser().resolve()


def prepare_output_dir(out_dir: Path, overwrite: bool) -> None:
    """Prepare output directory.

    We only remove known artifacts generated by this script to avoid deleting unrelated files.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    if not overwrite:
        return
    # Known output paths
    paths_to_remove = [
        out_dir / "ocr_results.jsonl",
        out_dir / "logs.txt",
        out_dir / "ocr_text",
        out_dir / "ocr_rois",
    ]
    for p in paths_to_remove:
        try:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            elif p.exists():
                p.unlink()
        except Exception as exc:  # pragma: no cover
            print(f"[WARN] Failed to clean {p}: {exc}")




def auto_canny(gray: np.ndarray, sigma: float = 0.33) -> np.ndarray:
    median = np.median(gray)
    lower = int(max(0, (1.0 - sigma) * median))
    upper = int(min(255, (1.0 + sigma) * median))
    if lower == upper:
        upper = min(255, lower + 30)
    edges = cv2.Canny(gray, lower, upper)
    return edges


def detect_coarse_rois(gray: np.ndarray) -> List[Tuple[int, int, int, int]]:
    edges = auto_canny(gray)
    height, width = gray.shape
    split_y = find_horizontal_split(edges)
    horizontal_segments: List[Tuple[int, int]] = []
    if split_y and 0 < split_y < height:
        if split_y - 0 > height * 0.15:
            horizontal_segments.append((0, split_y))
        if height - split_y > height * 0.15:
            horizontal_segments.append((split_y, height))
    if not horizontal_segments:
        horizontal_segments.append((0, height))
    rois: List[Tuple[int, int, int, int]] = []
    for y1, y2 in horizontal_segments:
        segment_edges = edges[y1:y2, :]
        vertical_segments = split_vertical(segment_edges)
        for x1, x2 in vertical_segments:
            abs_x1 = max(0, x1)
            abs_x2 = min(width, x2)
            if abs_x2 - abs_x1 < width * 0.1:
                continue
            rois.append((abs_x1, y1, abs_x2, y2))
    return rois or [(0, 0, width, height)]


def find_horizontal_split(edges: np.ndarray) -> Optional[int]:
    height, _ = edges.shape
    projection = edges.sum(axis=1)
    start = int(height * 0.2)
    end = int(height * 0.8)
    window = projection[start:end]
    if window.size == 0:
        return None
    idx = int(np.argmax(window))
    peak = window[idx]
    mean = float(window.mean() + 1e-5)
    global_mean = float(projection.mean() + 1e-5)
    split_y = idx + start
    if (
        peak > mean * 1.8
        and peak > global_mean * 2.0
        and int(height * 0.25) < split_y < int(height * 0.75)
    ):
        return split_y
    return None


def split_vertical(edges: np.ndarray) -> List[Tuple[int, int]]:
    height, width = edges.shape
    projection = edges.sum(axis=0)
    threshold = float(projection.mean() + projection.std())
    if threshold == 0:
        return [(0, width)]
    candidates = np.argsort(projection)[::-1]
    splits: List[int] = []
    max_splits = 2
    for idx in candidates:
        if projection[idx] < threshold or len(splits) >= max_splits:
            break
        if any(abs(idx - existing) < width * 0.12 for existing in splits):
            continue
        splits.append(int(idx))
    if not splits:
        return [(0, width)]
    splits = sorted(splits)
    segments: List[Tuple[int, int]] = []
    prev = 0
    for split in splits:
        if split - prev > width * 0.15:
            segments.append((prev, split))
            prev = split
    if width - prev > width * 0.1:
        segments.append((prev, width))
    if not segments:
        return [(0, width)]
    return segments[:3]


def refine_rois_for_block(
    block_img: np.ndarray,
    block_edges: np.ndarray,
    origin_box: Tuple[int, int, int, int],
    global_area: int,
) -> List[CandidateROI]:
    x_offset, y_offset = origin_box[0], origin_box[1]
    block_h, block_w = block_edges.shape
    if block_h == 0 or block_w == 0:
        return []
    kernel_w = max(3, int(block_w / 40))
    kernel_h = max(3, int(block_h / 60))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT, (kernel_w | 1, max(3, kernel_h | 1))
    )
    morphed = cv2.morphologyEx(block_edges, cv2.MORPH_CLOSE, kernel, iterations=1)
    contours, _ = cv2.findContours(
        morphed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    candidates: List[CandidateROI] = []
    for contour in contours:
        x, y, w_box, h_box = cv2.boundingRect(contour)
        area = w_box * h_box
        if area < global_area * MIN_AREA_RATIO or (w_box < 20 and h_box < 20):
            continue
        abs_x1 = max(0, x + x_offset)
        abs_y1 = max(0, y + y_offset)
        abs_x2 = abs_x1 + w_box
        abs_y2 = abs_y1 + h_box
        roi_edges = block_edges[y : y + h_box, x : x + w_box]
        density = float(roi_edges.sum()) / (area * 255.0 + 1e-5)
        score = 0.7 * (area / global_area) + 0.3 * density
        candidates.append(CandidateROI((abs_x1, abs_y1, abs_x2, abs_y2), score))
    if not candidates:
        candidates.append(
            CandidateROI(
                (origin_box[0], origin_box[1], origin_box[2], origin_box[3]),
                origin_box[2] - origin_box[0],
            )
        )
    return candidates


def compute_iou(box_a: Tuple[int, int, int, int], box_b: Tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b
    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)
    if inter_x2 <= inter_x1 or inter_y2 <= inter_y1:
        return 0.0
    inter_area = (inter_x2 - inter_x1) * (inter_y2 - inter_y1)
    area_a = (ax2 - ax1) * (ay2 - ay1)
    area_b = (bx2 - bx1) * (by2 - by1)
    return float(inter_area) / float(area_a + area_b - inter_area + 1e-5)


def deduplicate_rois(
    rois: List[CandidateROI], iou_thresh: float = 0.85
) -> List[CandidateROI]:
    rois = sorted(rois, key=lambda r: r.score, reverse=True)
    filtered: List[CandidateROI] = []
    for roi in rois:
        if any(compute_iou(roi.box, kept.box) > iou_thresh for kept in filtered):
            continue
        filtered.append(roi)
    return filtered


def ensure_full_roi(
    rois: List[CandidateROI],
    full_box: Tuple[int, int, int, int],
    max_rois: int,
) -> List[CandidateROI]:
    full_present = any(compute_iou(roi.box, full_box) > 0.98 for roi in rois)
    if not full_present:
        rois.append(CandidateROI(full_box, score=1.0))
    if len(rois) <= max_rois:
        return rois
    rois = sorted(rois[:-1], key=lambda r: r.score, reverse=True)
    rois = rois[: max(0, max_rois - 1)]
    rois.append(CandidateROI(full_box, score=1.0))
    return rois


def classify_roi(img: np.ndarray, ocr_engine: PaddleOCR) -> str:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = auto_canny(gray)
    edge_density = float(edges.mean()) / 255.0
    sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    horiz_ratio = (np.mean(np.abs(sobelx)) + 1e-5) / (np.mean(np.abs(sobely)) + 1e-5)
    row_projection = edges.sum(axis=1)
    row_std = np.std(row_projection)
    row_mean = np.mean(row_projection) + 1e-5
    heuristics_score = 0
    if edge_density > 0.08:
        heuristics_score += 1
    if horiz_ratio > 1.15:
        heuristics_score += 1
    if row_std / row_mean > 1.5 and edge_density > 0.05:
        heuristics_score += 1
    if heuristics_score >= 2:
        return "code_like"
    quick_text = quick_ocr_text(img, ocr_engine, logger=None)
    if quick_text:
        if compute_symbol_ratio(quick_text) >= 0.12:
            return "code_like"
        lower = quick_text.lower()
        if any(keyword in lower for keyword in ERROR_KEYWORDS):
            return "code_like"
    return "ui_like"


def quick_ocr_text(img: np.ndarray, ocr_engine: PaddleOCR, logger: Optional[logging.Logger] = None) -> str:
    """Fast, low-cost OCR used for ROI classification heuristics.

    IMPORTANT: Convert BGR->RGB before feeding PaddleOCR.
    """
    height, width = img.shape[:2]
    scale = 640.0 / max(height, width)
    quick_img = img
    if scale < 1.0:
        quick_img = cv2.resize(
            img, (int(width * scale), int(height * scale)), interpolation=cv2.INTER_AREA
        )
    try:
        results = _call_paddle_ocr(ocr_engine, _to_rgb(quick_img), allow_cls=True)
    except Exception as exc:  # pragma: no cover
        if logger is not None:
            logger.exception("PaddleOCR quick_ocr_text failed: %s", exc)
        else:
            print(f"[OCR ERROR] quick_ocr_text: {exc}")
        return ""
    texts: List[str] = []
    for entry in _normalize_paddle_outputs(results):
        text = entry.get("text")
        if text:
            texts.append(str(text))
    return " ".join(texts)


def compute_symbol_ratio(text: str) -> float:
    if not text:
        return 0.0
    total = len(text)
    symbols = sum(1 for ch in text if ch in CODE_SYMBOLS)
    return symbols / max(1, total)


def preprocess_roi(
    img: np.ndarray, kind: str, upscale: int
) -> Tuple[np.ndarray, Dict[str, bool]]:
    info = {
        "upscale": upscale,
        "inverted": False,
        "binary": False,
        "clahe": False,
        "denoise": False,
        "sharpen": False,
        "contrast": False,
        "kind": kind,
    }
    work = img.copy()
    gray_sample = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
    if float(np.mean(gray_sample)) < 110:
        work = 255 - work
        info["inverted"] = True
    if upscale > 1:
        work = cv2.resize(
            work, (0, 0), fx=upscale, fy=upscale, interpolation=cv2.INTER_CUBIC
        )
    work = cv2.bilateralFilter(work, d=5, sigmaColor=25, sigmaSpace=25)
    info["denoise"] = True
    blur = cv2.GaussianBlur(work, (0, 0), 1.2)
    work = cv2.addWeighted(work, 1.5, blur, -0.5, 0)
    info["sharpen"] = True
    if kind == "code_like":
        work_gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
        clahe_code = _get_clahe("code_like")
        work_gray = clahe_code.apply(work_gray)
        info["clahe"] = True
        block_size = max(21, (work_gray.shape[1] // 20) | 1)
        binary = cv2.adaptiveThreshold(
            work_gray,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            block_size,
            8,
        )
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, _CODE_CLOSE_KERNEL, iterations=1)
        info["binary"] = True
        work = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
    else:
        lab = cv2.cvtColor(work, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe_ui = _get_clahe("ui_like")
        l = clahe_ui.apply(l)
        lab = cv2.merge((l, a, b))
        work = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        info["clahe"] = True
        work = cv2.convertScaleAbs(work, alpha=1.1, beta=5)
        info["contrast"] = True
    return work, info


def run_ocr_on_roi(
    ocr_engine: PaddleOCR,
    img: np.ndarray,
    logger: Optional[logging.Logger] = None,
) -> List[Dict[str, float]]:
    """Run PaddleOCR on a ROI image and return normalized token items.

    IMPORTANT: Convert BGR->RGB before feeding PaddleOCR.
    """
    try:
        results = _call_paddle_ocr(ocr_engine, _to_rgb(img), allow_cls=True)
    except Exception as exc:  # pragma: no cover
        if logger is not None:
            logger.exception("PaddleOCR failed: %s", exc)
        else:
            print(f"[OCR ERROR] run_ocr_on_roi: {exc}")
        return []
    items: List[Dict[str, float]] = []
    for entry in _normalize_paddle_outputs(results):
        text = entry.get("text")
        if not text:
            continue
        coords = _box_to_xyxy(entry.get("box"))
        if not coords:
            continue
        x1, y1, x2, y2 = coords
        height = max(1, y2 - y1)
        items.append(
            {
                "x1": float(x1),
                "x2": float(x2),
                "y1": float(y1),
                "y2": float(y2),
                "cy": float((y1 + y2) / 2.0),
                "height": float(height),
                "text": text,
                "score": float(entry.get("score", 0.0)),
            }
        )
    return items


def reconstruct_lines(
    items: List[Dict[str, float]], kind: str, roi_width: int
) -> List[str]:
    if not items:
        return []
    items = sorted(items, key=lambda it: (it["cy"], it["x1"]))
    heights = [it["height"] for it in items if it["height"] > 0]
    median_height = float(np.median(heights)) if heights else 12.0
    if kind == "code_like":
        tol = max(6.0, 0.45 * median_height)
    else:
        tol = max(10.0, 0.8 * median_height)
    groups: List[Dict[str, float]] = []
    for item in items:
        placed = False
        for group in groups:
            if abs(group["cy"] - item["cy"]) <= tol:
                group["items"].append(item)
                group["cy"] = (group["cy"] * len(group["items"]) + item["cy"]) / (
                    len(group["items"]) + 1
                )
                group["min_y"] = min(group["min_y"], item["y1"])
                group["max_y"] = max(group["max_y"], item["y2"])
                placed = True
                break
        if not placed:
            groups.append(
                {
                    "cy": item["cy"],
                    "items": [item],
                    "min_y": item["y1"],
                    "max_y": item["y2"],
                }
            )
    groups = sorted(groups, key=lambda g: g["cy"])
    char_widths = [
        (itm["x2"] - itm["x1"]) / max(1, len(itm["text"])) for itm in items if itm["text"]
    ]
    avg_char_width = float(np.median(char_widths)) if char_widths else max(roi_width / 80, 2)
    lines: List[str] = []
    prev_max_y = None
    gap_threshold = tol * 1.4
    for group in groups:
        if (
            prev_max_y is not None
            and group["min_y"] - prev_max_y > gap_threshold
            and kind == "code_like"
        ):
            lines.append("")
        line_items = sorted(group["items"], key=lambda it: it["x1"])
        if kind == "code_like":
            line_text: List[str] = []
            for idx, item in enumerate(line_items):
                if idx == 0:
                    indent = int(round(item["x1"] / max(1.0, avg_char_width)))
                    if indent > 0:
                        line_text.append(" " * indent)
                else:
                    gap = item["x1"] - line_items[idx - 1]["x2"]
                    if gap > avg_char_width * 0.6:
                        spaces = max(1, int(round(gap / max(1.0, avg_char_width))))
                        line_text.append(" " * spaces)
                    else:
                        line_text.append(" ")
                line_text.append(item["text"])
            line = "".join(line_text).rstrip()
        else:
            line = " ".join(it["text"] for it in line_items)
            line = re.sub(r"\s+", " ", line).strip()
        lines.append(line)
        prev_max_y = group["max_y"]
    return lines


def normalize_code_lines(lines: Sequence[str]) -> str:
    normalized: List[str] = []
    for line in lines:
        norm_line = unicodedata.normalize("NFKC", line or "")
        norm_line = (
            norm_line.replace("\u201c", '"')
            .replace("\u201d", '"')
            .replace("\u2018", "'")
            .replace("\u2019", "'")
        )
        buffer = []
        for ch in norm_line:
            if ch in CODE_SYMBOLS or ch.isalnum() or ch in {" ", "\t"}:
                buffer.append(ch)
            elif ch == "\u3000":
                buffer.append(" ")
        out_line = "".join(buffer).replace("\t", "    ")
        normalized.append(out_line.rstrip())
    return "\n".join(normalized).strip("\n")


def build_symbol_light(text: str) -> str:
    if not text:
        return ""
    mapped = text.translate(SYMBOL_LIGHT_MAP)
    mapped = re.sub(r"[()]{2,}", lambda m: m.group(0)[0], mapped)
    return mapped


def normalize_ui_lines(lines: Sequence[str]) -> str:
    cleaned: List[str] = []
    for line in lines:
        norm = unicodedata.normalize("NFKC", line or "")
        norm = re.sub(r"\s+", " ", norm).strip()
        cleaned.append(norm)
    return "\n".join(cleaned).strip()


def save_roi_crop(
    roi_img: np.ndarray, rois_dir: Path, image_stem: str, roi_index: int
) -> None:
    rois_dir.mkdir(parents=True, exist_ok=True)
    roi_path = rois_dir / f"{image_stem}__roi{roi_index}.png"
    cv2.imwrite(str(roi_path), roi_img)


def process_image(
    image_path: Path,
    args: argparse.Namespace,
    ocr_engine: PaddleOCR,
    text_dir: Path,
    rois_dir: Optional[Path],
    logger: logging.Logger,
) -> Tuple[List[Dict[str, object]], List[Tuple[int, Tuple[int, int, int, int], str, float, str]]]:
    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Failed to read image {image_path}")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    coarse_boxes = detect_coarse_rois(gray)
    candidates: List[CandidateROI] = []
    global_area = image.shape[0] * image.shape[1]
    for box in coarse_boxes:
        x1, y1, x2, y2 = box
        block_img = image[y1:y2, x1:x2]
        block_gray = cv2.cvtColor(block_img, cv2.COLOR_BGR2GRAY)
        block_edges = auto_canny(block_gray)
        candidates.extend(
            refine_rois_for_block(block_img, block_edges, box, global_area)
        )
    candidates = deduplicate_rois(candidates)
    full_box = (0, 0, image.shape[1], image.shape[0])
    candidates = ensure_full_roi(candidates, full_box, args.max_rois)
    records: List[Dict[str, object]] = []
    text_sections: List[
        Tuple[int, Tuple[int, int, int, int], str, float, str]
    ] = []
    for idx, roi in enumerate(candidates, start=1):
        x1, y1, x2, y2 = roi.box
        roi_img = image[y1:y2, x1:x2]
        if roi_img.size == 0:
            continue
        roi_kind_initial = classify_roi(roi_img, ocr_engine)
        roi_kind = roi_kind_initial
        processed_img, preprocess_info = preprocess_roi(roi_img, roi_kind, args.upscale)
        ocr_items = run_ocr_on_roi(ocr_engine, processed_img, logger)
        if not ocr_items and roi_kind_initial == "code_like":
            alt_img, alt_info = preprocess_roi(roi_img, "ui_like", args.upscale)
            alt_items = run_ocr_on_roi(ocr_engine, alt_img, logger)
            if alt_items:
                processed_img = alt_img
                preprocess_info = alt_info
                preprocess_info["fallback_from_code_like"] = True
                ocr_items = alt_items
                roi_kind = "ui_like"
        if not ocr_items:
            # Fallback: try original ROI (no aggressive preprocess) to avoid losing faint text
            fallback_try_original_roi = cv2.resize(
                roi_img,
                (0, 0),
                fx=max(1, args.upscale),
                fy=max(1, args.upscale),
                interpolation=cv2.INTER_CUBIC,
            )
            ocr_items = run_ocr_on_roi(ocr_engine, fallback_try_original_roi, logger)
            if ocr_items:
                processed_img = fallback_try_original_roi
                preprocess_info = {"fallback_original_roi": True, "upscale": args.upscale}

        lines = reconstruct_lines(
            ocr_items, roi_kind, roi_width=processed_img.shape[1]
        )
        raw_lines = [
            item["text"] for item in sorted(ocr_items, key=lambda it: (it["cy"], it["x1"]))
        ]
        text_raw = "\n".join(lines if lines else raw_lines)
        if roi_kind == "code_like":
            text_code_clean = normalize_code_lines(lines or raw_lines)
            text_symbol_light = build_symbol_light(text_code_clean)
            text_clean = text_code_clean
            text_ui_clean = ""
        else:
            text_ui_clean = normalize_ui_lines(lines or raw_lines)
            text_clean = text_ui_clean
            text_code_clean = ""
            text_symbol_light = ""
        has_text = bool((text_clean and text_clean.strip()) or (text_raw and text_raw.strip()))
        if not has_text:
            logger.info(
                "ROI %d skipped - empty OCR result, blank region removed",
                idx,
            )
            continue
        mean_conf = (
            float(np.mean([item["score"] for item in ocr_items])) if ocr_items else 0.0
        )
        record: Dict[str, object] = {
            "image_path": str(image_path),
            "roi_index": idx,
            "roi_box": [x1, y1, x2, y2],
            "roi_kind": roi_kind,
            "ocr_engine": "paddleocr",
            "lang": args.lang,
            "preprocess": preprocess_info,
            "ocr_mean_conf": round(mean_conf, 4),
            "text_raw": text_raw,
            "text_clean": text_clean,
            "lines": lines,
        }
        if roi_kind_initial != roi_kind:
            record["roi_kind_initial"] = roi_kind_initial
        if roi_kind == "code_like":
            record["text_code_clean"] = text_code_clean
            record["text_symbol_light"] = text_symbol_light
        else:
            record["text_ui_clean"] = text_ui_clean
        records.append(record)
        text_sections.append((idx, roi.box, roi_kind, mean_conf, text_clean))
        if args.save_rois and rois_dir is not None:
            save_roi_crop(roi_img, rois_dir, image_path.stem, idx)
        logger.info(
            "ROI %d (%s) - box=%s conf=%.3f text_len=%d",
            idx,
            roi_kind,
            roi.box,
            mean_conf,
            len(text_clean),
        )
    return records, text_sections


def write_text_file(
    text_dir: Path,
    image_path: Path,
    sections: List[Tuple[int, Tuple[int, int, int, int], str, float, str]],
) -> None:
    text_file = text_dir / f"{image_path.stem}.txt"
    if not sections:
        if text_file.exists():
            text_file.unlink()
        return
    text_dir.mkdir(parents=True, exist_ok=True)
    with text_file.open("w", encoding="utf-8") as handle:
        for idx, box, kind, conf, text in sections:
            handle.write(
                f"--- ROI {idx} [{box[0]},{box[1]},{box[2]},{box[3]}] kind={kind} conf={conf:.3f}\n"
            )
            handle.write((text or "") + "\n\n")


def process_repository(
    image_root: Path,
    args: argparse.Namespace,
    ocr_engine: PaddleOCR,
) -> None:
    try:
        image_dirs = discover_image_directories(image_root)
    except FileNotFoundError as exc:
        print(f"[WARN] {exc}")
        return
    if not image_dirs:
        print(f"[WARN] 目录 {image_root} 中未找到任何有效的 IMAGE 子目录，已跳过。")
        return
    total_instances = len(image_dirs)
    for repo_idx, image_dir in enumerate(image_dirs, start=1):
        try:
            image_paths = list_image_paths(image_dir)
        except FileNotFoundError as exc:
            print(f"[WARN] 跳过缺失的 IMAGE 目录 {image_dir}: {exc}")
            continue
        if not image_paths:
            print(f"[WARN] 目录 {image_dir} 中未找到任何截图，已跳过。")
            continue
        instance_label = image_dir.parent.name or image_dir.name
        out_dir = resolve_output_dir(image_dir, args)
        prepare_output_dir(out_dir, args.overwrite_outputs)
        jsonl_path = out_dir / "ocr_results.jsonl"
        text_dir = image_dir / "OCR_TXT"
        if args.overwrite_outputs and text_dir.exists():
            try:
                if text_dir.is_dir():
                    shutil.rmtree(text_dir, ignore_errors=True)
                else:
                    text_dir.unlink()
            except Exception as exc:
                print(f"[WARN] Failed to clean text output dir {text_dir}: {exc}")
        rois_dir = out_dir / "ocr_rois" if args.save_rois else None
        log_file = out_dir / "logs.txt"
        logger = setup_logger(log_file)
        logger.info(
            "Processing %s (%d/%d) with %d images",
            image_dir,
            repo_idx,
            total_instances,
            len(image_paths),
        )
        total_images = len(image_paths)
        worker_count = max(1, args.max_workers)
        with jsonl_path.open("w", encoding="utf-8") as jsonl_handle:
            processed = 0

            def _emit_outputs(image_path: Path, records: List[Dict[str, object]], sections):
                nonlocal processed
                for record in records:
                    jsonl_handle.write(json.dumps(record, ensure_ascii=False) + "\n")
                write_text_file(text_dir, image_path, sections)
                processed += 1
                render_progress(instance_label, processed, total_images)

            if worker_count == 1:
                for idx, image_path in enumerate(image_paths, start=1):
                    logger.info(
                        "Processing %s (%d/%d)",
                        image_path,
                        idx,
                        total_images,
                    )
                    try:
                        records, sections = process_image(
                            image_path, args, ocr_engine, text_dir, rois_dir, logger
                        )
                    except Exception as exc:  # pragma: no cover - defensive logging
                        logger.exception("Failed to process %s: %s", image_path, exc)
                        records, sections = [], []
                    _emit_outputs(image_path, records, sections)
            else:
                logger.info("Using %d worker threads for OCR", worker_count)
                future_map = {}
                next_to_emit = 1
                pending: Dict[int, Tuple[List[Dict[str, object]], List[Tuple[int, Tuple[int, int, int, int], str, float, str]], Path]] = {}
                with ThreadPoolExecutor(max_workers=worker_count) as executor:
                    for idx, image_path in enumerate(image_paths, start=1):
                        logger.info(
                            "Processing %s (%d/%d)",
                            image_path,
                            idx,
                            total_images,
                        )
                        future = executor.submit(
                            process_image,
                            image_path,
                            args,
                            ocr_engine,
                            text_dir,
                            rois_dir,
                            logger,
                        )
                        future_map[future] = (idx, image_path)
                    for fut in as_completed(future_map):
                        idx, image_path = future_map[fut]
                        try:
                            records, sections = fut.result()
                        except Exception as exc:  # pragma: no cover - defensive logging
                            logger.exception("Failed to process %s: %s", image_path, exc)
                            records, sections = [], []
                        pending[idx] = (records, sections, image_path)
                        while next_to_emit in pending:
                            recs, secs, img_path = pending.pop(next_to_emit)
                            _emit_outputs(img_path, recs, secs)
                            next_to_emit += 1
        logger.info("OCR finished. Results saved to %s", out_dir)
    print(f"[INFO] 目录 {image_root} 的所有 IMAGE 文件夹均已处理完毕。")


def main() -> None:
    args = parse_args()
    args.max_workers = sanitize_worker_count(args.max_workers)
    try:
        ocr_engine = PaddleOCR(use_textline_orientation=True, lang=args.lang)
    except TypeError:
        ocr_engine = PaddleOCR(use_angle_cls=True, lang=args.lang)
    image_roots = resolve_image_roots(args)
    if not image_roots:
        raise RuntimeError("未解析到任何需要处理的目录。")
    args.image_root = image_roots
    for image_root in image_roots:
        print(f"[INFO] 开始处理目录：{image_root}")
        process_repository(image_root, args, ocr_engine)


if __name__ == "__main__":
    main()
