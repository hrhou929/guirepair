task=run                             # please set run/val. run: generate fix； val: validate fix
output_file=result.json              # save fault localization result to this file
log_file=repair_$task.log            # save log to this file
base_model=o4-mini-2025-04-16        # gpt-4o-2024-08-06 or gpt-4.1-2025-04-14 or claude-3-5-sonnet-20240620
output_dir=$base_model/result_Image2Code
dataset=princeton-nlp/SWE-bench_Multimodal
dataset_split=test              # test/dev
val_patch_no=1                  # you can select the patch index 1-n to val the fix result. you can set 0 to replay the bug scenario
instance_id=ALL          # you need to set "ALL" or Repo_ID or only one Instance_Id e.g.,"chartjs__Chart.js-8868"
repo_path=/Volumes/T7/guirepair/Data/Reproduce_Scenario_partial #改地址 
Code_Reply=True                 # True: reproduce bug image by generating code; False: close ...
doc_RAG_query=False             # True: open RAG to query doc files
RAG_query=False                 # True: open RAG to query bug files by using issue reports; False: False: close RAG
keywords_searching=False        # True: using keywords form the bug images to search bug files; False: close ...
Checked_Exception=True          # True: open the exception to save un-checked function/class; False: close ...
Patch_Check=False               # True: check the compilation error or warning when applying the patch and solve these errors; False: close ...
Patch_Select=True               # True: select valid patch by viewing the visual effects of the patched program
File_Sort=True                  # True: sorted the dirs/files to show, just like the VSCode Repo dir/file structrue
max_lines_per_snippet=500       # The context window of the Exception Func/Class
context_window=0
bug_keywords_temperature=0.0
bug_keywords_samples=1
bug_docs_temperature=0.0
bug_docs_samples=1
code_reproduce_temperature=0.0
code_reproduce_samples=1
all_bug_file_temperature=1          # 0.7
all_bug_file_samples=2              # 2
max_candidate_bug_files=4           # 4
max_candidate_doc_files=6           # 8/6/4
key_bug_file_temperature=0.0             # 0.0
key_bug_file_samples=1                   # 1
max_lines_per_key_file=500               # The context window of the key bug file 
key_bug_class_function_temperature=0.7   # 0.7
key_bug_class_function_samples=2         # 4
line_level_fl_temperature=0.9
line_level_fl_samples=40
patch_generation_temperature=1     # 0.8
patch_generation_samples=1
wait_time_after_api_request=0      # please set 0s if your api no request limit
wait_time_after_build=5            # you need leave some time to check bug scenario

mkdir -p $output_dir

if [[ "$instance_id" == *"__"* ]]; then
    instance_prefix=$(echo $instance_id | awk -F'__' '{print $1}')
    log_file_path=$output_dir/$dataset_split/$instance_prefix/$instance_id
else
    log_file_path=$output_dir/$dataset_split/$instance_id
fi

mkdir -p $log_file_path


python main.py \
    --task $task\
    --output_dir $output_dir\
    --output_file $output_file\
    --base_model $base_model\
    --dataset $dataset\
    --dataset_split $dataset_split\
    --instance_id $instance_id\
    --repo_path $repo_path\
    --Code_Reply $Code_Reply\
    --doc_RAG_query $doc_RAG_query\
    --RAG_query $RAG_query\
    --keywords_searching $keywords_searching\
    --bug_keywords_temperature $bug_keywords_temperature\
    --bug_keywords_samples $bug_keywords_samples\
    --bug_docs_temperature $bug_docs_temperature\
    --bug_docs_samples $bug_docs_samples\
    --max_candidate_doc_files $max_candidate_doc_files\
    --code_reproduce_temperature $code_reproduce_temperature\
    --code_reproduce_samples $code_reproduce_samples\
    --Checked_Exception $Checked_Exception\
    --max_lines_per_snippet $max_lines_per_snippet\
    --context_window $context_window\
    --all_bug_file_temperature $all_bug_file_temperature\
    --all_bug_file_samples $all_bug_file_samples\
    --max_candidate_bug_files $max_candidate_bug_files\
    --key_bug_file_temperature $key_bug_file_temperature\
    --key_bug_file_samples $key_bug_file_samples\
    --key_bug_class_function_temperature $key_bug_class_function_temperature\
    --key_bug_class_function_samples $key_bug_class_function_samples\
    --line_level_fl_temperature $line_level_fl_temperature\
    --line_level_fl_samples $line_level_fl_samples\
    --patch_generation_temperature $patch_generation_temperature\
    --patch_generation_samples $patch_generation_samples\
    --wait_time_after_api_request $wait_time_after_api_request\
    --wait_time_after_build $wait_time_after_build\
    --val_patch_no $val_patch_no\
    --Patch_Check $Patch_Check\
    --Patch_Select $Patch_Select\
    --File_Sort $File_Sort\
    2>&1 | tee $log_file_path/$log_file

