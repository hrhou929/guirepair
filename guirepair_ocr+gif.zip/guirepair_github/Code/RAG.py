import os
import openai
import faiss
import numpy as np
from openai import OpenAI


# My API KEY
openai.api_key = os.getenv("OPENAI_API_KEY", "")


client = OpenAI(
    api_key=openai.api_key if openai.api_key else None,
    base_url=os.getenv("OPENAI_API_BASE", None)
)
# 1. Embedding
def get_embedding(text):
    
    response = client.embeddings.create(
        input=text,
        model="text-embedding-3-small"
        # model="text-embedding-ada-002"
    )
    return response.data[0].embedding


def load_code_files(repo_path):
    code_files = {}
    for root, _, files in os.walk(repo_path):
        for file in files:
            if file.endswith((".js", ".jsx", ".ts", ".tsx", ".scss", ".lua", ".json")):
                with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                    code_files[os.path.join(root, file)] = f.read()
    return code_files

def query_doc_file(logger, doc_repo_path, doc_files_path, top_k_files, issue_description):

    # Filter out macOS hidden files (._* files)
    filtered_doc_files_path = [doc_path for doc_path in doc_files_path if not doc_path.split('/')[-1].startswith('._')]
    all_doc_files_path = [doc_repo_path+doc_path for doc_path in filtered_doc_files_path]

    logger.info(f'Filtered {len(doc_files_path) - len(filtered_doc_files_path)} hidden files, processing {len(filtered_doc_files_path)} documents')

    code_files = {}
    for doc_file_name in all_doc_files_path:
        with open(doc_file_name, "r", encoding="utf-8") as f:
            try:
                code_files[doc_file_name] = f.read()
            except:
                code_files[doc_file_name] = ''

    # Batch embedding for efficiency
    embeddings = []
    file_contents = [content[:2000] for content in code_files.values()]

    # OpenAI allows batch embedding (max 2048 items per request)
    batch_size = 100
    for i in range(0, len(file_contents), batch_size):
        batch = file_contents[i:i+batch_size]
        response = client.embeddings.create(input=batch, model="text-embedding-3-small")
        embeddings.extend([data.embedding for data in response.data])


    dimension = len(embeddings[0])
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings).astype('float32'))


    # issue_description = """blendMode not working when doing point() drawing in webgl"""
    issue_embedding = get_embedding(issue_description)

    D, I = index.search(np.array([issue_embedding]).astype('float32'), k=top_k_files)


    bug_files_rag = []
    # print("Potential bug files:")
    for i in I[0]:
        # print(file_paths[i])
        # bug_files_rag.append(file_paths[i])
        bug_files_rag.append(all_doc_files_path[i].replace(doc_repo_path+'/','').replace('\\','/'))

    return bug_files_rag


def query_bug_file(logger, bug_repo_path, no1_bug_file_path_list, top_k_files, issue_description):

    code_files_dict = {}
    for No1_bug_file_path in no1_bug_file_path_list:
        repo_path = bug_repo_path + '/' + No1_bug_file_path
        code_files = load_code_files(repo_path)
        for file_name in code_files.keys():
            code_files_dict[file_name] = code_files[file_name]

    file_paths = list(code_files_dict.keys())
    logger.info(f'Processing {len(file_paths)} code files for embedding')

    # Check if there are any files to process
    if len(file_paths) == 0:
        logger.warning('No code files found for RAG query. Returning empty list.')
        return []

    # Batch embedding for efficiency
    embeddings = []
    file_contents = [content[:2000] for content in code_files_dict.values()]

    # OpenAI allows batch embedding (max 2048 items per request)
    batch_size = 100
    for i in range(0, len(file_contents), batch_size):
        batch = file_contents[i:i+batch_size]
        response = client.embeddings.create(input=batch, model="text-embedding-3-small")
        embeddings.extend([data.embedding for data in response.data])


    dimension = len(embeddings[0])
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings).astype('float32'))


    # issue_description = """blendMode not working when doing point() drawing in webgl"""

    if 'Related Documents:' in issue_description:
        issue_description = issue_description.split('Related Documents:')[0]
    issue_embedding = get_embedding(issue_description)

    D, I = index.search(np.array([issue_embedding]).astype('float32'), k=top_k_files)


    bug_files_rag = []
    print("Potential bug files:")
    for i in I[0]:
        # print(file_paths[i])
        # bug_files_rag.append(file_paths[i])
        bug_files_rag.append(file_paths[i].replace(bug_repo_path+'/','').replace('\\','/'))

    return bug_files_rag