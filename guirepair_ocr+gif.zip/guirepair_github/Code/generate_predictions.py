import argparse
import json
from pathlib import Path

# ===== Manual switches (edit defaults here) =====
# Default root directory that contains instance result folders
SOURCE_DIR_DEFAULT = "Code/o4-mini-2025-04-16/result/test"
# Default output file for predictions JSON
OUTPUT_PATH_DEFAULT = "Result/o4-mini/submit_patches/predictions_GUIRepair_o4mini.json"
# Default repo filter: comma-separated repo prefixes; empty string means include all
REPO_FILTER_DEFAULT = ""


def collect_predictions(source_dir: Path, model_name: str, repo_filters: set | None) -> dict:
    predictions = {}
    # Walk recursively to support layouts like <source_dir>/<repo>/<instance>/changes.diff
    for diff_file in sorted(source_dir.rglob("changes.diff")):
        instance_dir = diff_file.parent
        repo_prefix = instance_dir.name.split("__")[0]
        if repo_filters and repo_prefix not in repo_filters:
            continue

        patch_text = diff_file.read_text(encoding="utf-8", errors="ignore").strip()
        if not patch_text:
            continue

        predictions[instance_dir.name] = {
            "model_patch": patch_text,
            "model_name_or_path": model_name,
        }
    return predictions


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Collect GUIRepair patch diffs into a SWE-bench submission JSON "
            "(predictions_*.json) file."
        )
    )
    parser.add_argument(
        "--source_dir",
        default=SOURCE_DIR_DEFAULT,
        help="Root directory containing instance result folders (e.g., Code/o4-mini-2025-04-16/result/test/PrismJS)",
    )
    parser.add_argument(
        "--output",
        default=OUTPUT_PATH_DEFAULT,
        help="Output predictions JSON path (e.g., Result/o4-mini/submit_patches/predictions_GUIRepair_o4mini.json)",
    )
    parser.add_argument(
        "--repo_filter",
        default=REPO_FILTER_DEFAULT,
        help=(
            "Comma-separated repo prefixes to include under source_dir. "
            "Example: 'PrismJS,openlayers'. If empty, include all."
        ),
    )
    parser.add_argument(
        "--model_name",
        default="GUIRepair",
        help="Model name to record under model_name_or_path. Default: GUIRepair",
    )
    args = parser.parse_args()

    source_dir = Path(args.source_dir).resolve()
    output_path = Path(args.output).resolve()
    repo_filters = {r.strip() for r in args.repo_filter.split(",") if r.strip()}

    if not source_dir.is_dir():
        raise SystemExit(f"[ERROR] Source directory not found: {source_dir}")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    predictions = collect_predictions(source_dir, args.model_name, repo_filters or None)
    if not predictions:
        raise SystemExit(f"[WARN] No predictions found under {source_dir}")

    # Avoid overwriting an existing file: if the target exists, add a numeric suffix.
    final_output = output_path
    if final_output.exists():
        parent = final_output.parent
        stem = final_output.stem
        suffix = final_output.suffix or ".json"
        counter = 1
        while True:
            candidate = parent / f"{stem}_{counter}{suffix}"
            if not candidate.exists():
                final_output = candidate
                break
            counter += 1

    with final_output.open("w", encoding="utf-8") as f:
        json.dump(predictions, f, indent=4)

    print(f"[INFO] Wrote {len(predictions)} predictions to {final_output}")


if __name__ == "__main__":
    main()
