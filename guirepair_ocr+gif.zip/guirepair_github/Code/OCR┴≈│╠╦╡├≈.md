# OCR 流程说明

本文档介绍 `Code/ocr_paddle2.py` 中的关键流水线，方便在 GUIRepair 工作流前置执行 OCR 预处理时理解各阶段职责与可配置项。

## 1. 启动与参数解析
- 通过 `python ocr_paddle2.py --image_root <目录>` 启动，脚本支持多次指定 `--image_root`，或使用 `--interactive_repo` 进行人工选择。
- 其他常用参数：
  - `--lang`: 选择 PaddleOCR 的语言模型（`en`/`ch`）。
  - `--upscale`: ROI 放大倍数，1~4，可提高小字体识别率。
  - `--max_rois`: 每张图最多处理的 ROI 数量。
  - `--save_rois`: 是否保存 ROI 截图以便复核。
  - `--overwrite_outputs`: 控制是否清空旧的 OCR_OUT 目录。
  - `--max_workers`: 处理同一 repo 下多张截图时的线程数（默认 1，0 表示自动接近 `CPU数-1`）。

## 2. 定位待处理截图
1. 调用 `resolve_image_roots` 将 CLI 指定的目录转为 `IMAGE` 文件夹；
2. `discover_image_directories` 会自动剔除 REPO 目录，且支持在 preset 列表中批处理多个实例；
3. 每个 image_root 内，`list_image_paths` 按递归方式收集全部图片（PNG/JPG/JPEG/WEBP），忽略 `OCR_OUT` 的缓存内容。

## 3. 预备输出目录
- 每个实例会在 `IMAGE/OCR_OUT` 下生成：
  - `ocr_results.jsonl`: 逐 ROI 的 OCR 结果；
  - `OCR_TXT/`: 每张图的纯文本摘要；
  - 可选的 `ocr_rois/`: 预处理前的 ROI 截图；
  - `logs.txt`: PaddleOCR 触发异常或 ROI 统计信息。
- 通过 `prepare_output_dir` 以及 `setup_logger` 保证日志与输出结构可重复使用。

## 4. 逐图像处理流程
对于每张截图，`process_image` 包含以下步骤：

1. **粗粒度 ROI 划分**  
   `detect_coarse_rois` 结合 Canny 边缘、水平/垂直投影，先将截图拆分为若干块；
2. **ROI 细化**  
   `refine_rois_for_block`、`deduplicate_rois`、`ensure_full_roi` 按面积与位置过滤，同时确保整图 ROI 始终存在；
3. **ROI 分类**  
   `classify_roi` 先通过边缘/梯度特征打分，再用一次简易 OCR 判断是否“code_like”，以便采用不同的预处理；
4. **图像预处理**  
   `preprocess_roi` 对 code_like 应用 CLAHE + 自适应阈值 + 形态学闭运算，对 UI-like 则进行 LAB CLAHE + 对比度增强；
5. **OCR 调用**  
   对每个 ROI 调用 `_call_paddle_ocr` 并通过 `_normalize_paddle_outputs` 统一格式；若无结果会尝试备用流程（UI 模式或原图）；
6. **文本重建**  
   `reconstruct_lines` 将同一行的 tokens 合并，`normalize_code_lines`、`normalize_ui_lines` 和 `build_symbol_light` 进一步清洗；
7. **输出记录**  
   每个 ROI 生成 JSON 记录（包括坐标、类型、置信度、预处理信息等）并写入 `ocr_results.jsonl`，同时生成文本摘要文件。

## 5. 并行与顺序保证
- 在 `process_repository` 中，当 `max_workers>1` 时使用 `ThreadPoolExecutor` 并行处理多张截图；
- 通过一个待发射队列，确保写入 `ocr_results.jsonl` 与 `OCR_TXT` 的顺序仍按原始图像顺序排列；
- PaddleOCR 本身非线程安全，因此 `_call_paddle_ocr` 使用全局锁，保证引擎状态一致。

## 6. 日志与进度
- `render_progress` 会实时输出每个实例的处理进度条（例如 `RepoName |####-----| 45.00% (9/20)`）；
- `logs.txt` 内记录了每个 ROI 的类型、置信度、文本长度等信息，方便排查漏识别或误识别。

## 7. 在 GUIRepair 中的使用
- 在 `Code/1_run_GUIRepair_base_o4mini.sh` 中设置 `run_ocr_paddle2=true` 后，脚本会在主流程启动前自动调用：  
  `python ocr_paddle2.py --image_root <repo_path/dataset_split/.../instance_id>`  
  确保 GUIRepair 后续步骤可直接消费最新的 OCR 输出。

## 常见问题
1. **PaddleOCR 报错 `unexpected keyword argument 'cls'`**  
   脚本会自动捕获并切换到兼容模式，无需手动处理。
2. **输出目录过大**  
   可以关闭 `--save_rois` 或设置 `--overwrite_outputs False` 保留历史结果。
3. **CPU 使用率高**  
   将 `--max_workers` 调整为 1 或更小值；对于 IO 密集型场景可设为 `CPU数-1` 获得更高吞吐量。

以上即为 OCR 流程概览，可根据需要调整参数或模块以适配新的截图格式/语言。***
