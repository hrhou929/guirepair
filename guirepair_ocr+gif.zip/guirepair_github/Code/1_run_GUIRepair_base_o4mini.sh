# export OPENAI_API_KEY="sk-EKSwMv0yAWYAfUsj401a3fF069754d8892B29718744c174f"
# export OPENAI_API_BASE="https://api.vveai.com/v1" 
# bash 1_run_GUIRepair_base_o4mini.sh
#或者用openai官方api

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

task=run                               # please set run/val. run: generate fix; val: validate fix
output_file=result.json                # save fault localization result to this file
log_file=repair_$task.log              # save log to this file
base_model=o4-mini-2025-04-16          # gpt-4o-2024-08-06 or gpt-4.1-2025-04-14 or o4-mini-2025-04-16 
output_dir=$base_model/result
dataset=princeton-nlp/SWE-bench_Multimodal
dataset_split=test
val_patch_no=1                          # you can select the patch index 1-n to val the fix result. you can set 0 to replay the bug scenario
instance_id=PrismJS          # you need to set "ALL" or specify multiple IDs separated by commas, e.g., "repo__id-1,repo__id-2"
repo_path="$PROJECT_ROOT/Reproduce_Scenario_partial" # root path containing dataset splits
RAG_query=True                # True: open RAG; False: False: close RAG
Checked_Exception=True         # True: open the exception to save un-checked function/class; False: close ...
max_lines_per_snippet=500      # The context window of the Exception Func/Class
context_window=0
all_bug_file_temperature=0.7          # 0.7
all_bug_file_samples=2              # 2
max_candidate_bug_files=8           # 4
key_bug_file_temperature=0.0             # 0.0
key_bug_file_samples=1                   # 1
max_lines_per_key_file=800               # The context window of the key bug file 
key_bug_class_function_temperature=0.7     # 0.7
key_bug_class_function_samples=4         # 4
line_level_fl_temperature=0.9
line_level_fl_samples=40
patch_generation_temperature=0.8     # 0.8
patch_generation_samples=4
wait_time_after_api_request=1      # please set 0s if your api no request limit
wait_time_after_build=5           # you need leave some time to check bug scenario
run_ocr_paddle2=True             # True: run Code/ocr_paddle2.py before GUIRepair; False: skip OCR preprocessing

mkdir -p $output_dir

# disable slow paddle model host checks unless user overrides
export DISABLE_MODEL_SOURCE_CHECK=${DISABLE_MODEL_SOURCE_CHECK:-True}

# Detect usable python interpreter (prefer local virtualenv)
if [[ -z "$PYTHON_BIN" ]]; then
    if [[ -x ".venv/bin/python" ]]; then
        PYTHON_BIN=".venv/bin/python"
    else
        PYTHON_BIN="python"
    fi
fi

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON_BIN=python3
    else
        echo "[ERROR] Cannot find python or python3 in PATH. Please install Python 3."
        exit 1
    fi
fi

run_instance() {
    local target_instance="$1"

    local instance_prefix=""
    if [[ "$target_instance" == *"__"* ]]; then
        instance_prefix=$(echo "$target_instance" | awk -F'__' '{print $1}')
        log_file_path=$output_dir/$dataset_split/$instance_prefix/$target_instance
    else
        log_file_path=$output_dir/$dataset_split/$target_instance
    fi
    mkdir -p "$log_file_path"

    if [[ "${run_ocr_paddle2,,}" == "true" ]]; then
        local ocr_target="$repo_path/$dataset_split"
        if [[ "$target_instance" != "ALL" && "$target_instance" != "all" ]]; then
            if [[ -n "$instance_prefix" ]]; then
                ocr_target="$ocr_target/$instance_prefix"
            fi
            ocr_target="$ocr_target/$target_instance"
        fi

        if [[ ! -d "$ocr_target" ]]; then
            echo "[WARN] ocr_paddle2 target directory not found: $ocr_target"
        elif [[ -d "$ocr_target/IMAGE/OCR_OUT" ]]; then
            echo "[INFO] OCR output already exists under: $ocr_target/IMAGE/OCR_OUT. Skipping OCR preprocessing."
        else
            echo "[INFO] Running OCR preprocessing via: python ocr_paddle2.py --image_root $ocr_target"
            "$PYTHON_BIN" ocr_paddle2.py --image_root "$ocr_target"
        fi
    fi

    "$PYTHON_BIN" main.py \
        --task $task\
        --output_dir $output_dir\
        --output_file $output_file\
        --base_model $base_model\
        --dataset $dataset\
        --dataset_split $dataset_split\
        --instance_id "$target_instance"\
        --repo_path $repo_path\
        --RAG_query $RAG_query\
        --Checked_Exception $Checked_Exception\
        --max_lines_per_snippet $max_lines_per_snippet\
        --context_window $context_window\
        --all_bug_file_temperature $all_bug_file_temperature\
        --all_bug_file_samples $all_bug_file_samples\
        --max_candidate_bug_files $max_candidate_bug_files\
        --key_bug_file_temperature $key_bug_file_temperature\
        --key_bug_file_samples $key_bug_file_samples\
        --key_bug_class_function_temperature $key_bug_class_function_temperature\
        --key_bug_class_function_samples $key_bug_class_function_samples\
        --line_level_fl_temperature $line_level_fl_temperature\
        --line_level_fl_samples $line_level_fl_samples\
        --patch_generation_temperature $patch_generation_temperature\
        --patch_generation_samples $patch_generation_samples\
        --wait_time_after_api_request $wait_time_after_api_request\
        --wait_time_after_build $wait_time_after_build\
        --val_patch_no $val_patch_no\
        2>&1 | tee "$log_file_path/$log_file"
}

IFS=',' read -ra requested_instances <<< "$instance_id"
expanded_instances=()

for raw_instance in "${requested_instances[@]}"; do
    current_instance=$(echo "$raw_instance" | xargs)
    [[ -z "$current_instance" ]] && continue

    if [[ "${current_instance^^}" == "ALL" ]]; then
        expanded_instances=("ALL")
        break
    elif [[ "$current_instance" == *"__"* ]]; then
        expanded_instances+=("$current_instance")
    else
        repo_dir="$repo_path/$dataset_split/$current_instance"
        if [[ -d "$repo_dir" ]]; then
            found_child=0
            while IFS= read -r entry; do
                [[ -d "$repo_dir/$entry" ]] || continue
                if [[ "$entry" == *"__"* ]]; then
                    expanded_instances+=("$entry")
                    found_child=1
                fi
            done < <(LC_ALL=C ls -1 "$repo_dir")

            if [[ $found_child -eq 0 ]]; then
                expanded_instances+=("$current_instance")
            fi
        else
            expanded_instances+=("$current_instance")
        fi
    fi
done

if [[ ${#expanded_instances[@]} -eq 0 ]]; then
    expanded_instances=("${requested_instances[@]}")
fi

for instance_to_run in "${expanded_instances[@]}"; do
    run_instance "$instance_to_run"
done
